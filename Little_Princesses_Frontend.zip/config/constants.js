const TODAY_STR = TODAY_STR_ISO;
const TODAY_DATE = new Date();
const DAY_STR = String(TODAY_DATE.getDate()).padStart(2, '0');
const MONTH_STR = String(TODAY_DATE.getMonth() + 1).padStart(2, '0');
const YEAR_STR = TODAY_DATE.getFullYear();
const TODAY_STR_ISO = `${YEAR_STR}-${MONTH_STR}-${DAY_STR}`;
const TODAY_STR_DISPLAY = `${DAY_STR}/${MONTH_STR}/${YEAR_STR}`;

function formatDateDisplay(dateStr) {
  if (!dateStr) return TODAY_STR_DISPLAY;
  if (dateStr.includes('/')) return dateStr;
  const parts = dateStr.split('-');
  if (parts.length === 3) {
    return `${parts[2].padStart(2, '0')}/${parts[1].padStart(2, '0')}/${parts[0]}`;
  }
  return dateStr;
}

const GAS_WEB_APP_URL = "http://127.0.0.1:5000/api/gas";

const ORG_NAME = "Little Princesses Organization - Specializing in Children's Garments";
const ORG_SHORT_TITLE = "Little Princesses Organisation | ERP 👑";

const PLATFORMS = [
  "انستغرام (Instagram)", "فيسبوك (Facebook)", "واتساب (WhatsApp)",
  "تيك توك (TikTok)", "سناب شات (Snapchat)", "تليجرام (Telegram)", "مباشر / زيارة المحل"
];

const CURRENCIES = ["USD $", "YER ﷼", "SAR ﷼"];

const FABRIC_CATEGORIES = ["أقمشة سهرة", "أقمشة فاخرة", "أقمشة خفيفة", "أقمشة مدرسية", "دانتيل وإكسسوارات", "مستلزمات خياطة"];

const PRODUCT_CATEGORIES = ["(Princess) فستان أميرة", "فساتين سهرة", "فساتين زفاف", "فساتين خطوبة", "زي مدرسي للأطفال"];

const FACTORY_STAGES = [
  "مرحلة القص والتحضير ✂️", "مرحلة الخياطة والتجميع 🪡",
  "مرحلة التطريز والتركيب 👑", "مرحلة الكي والتغليف 🎁", "جاهز للتسليم للعميلة ✨"
];

const EXPENSE_CATEGORIES = [
  "502 - إيجار الورشة والمعمل والمحل الرئيسي",
  "503 - كهرباء وماء وإنترنت واستضافة المتجر",
  "501 - أجور ورواتب الخياطين والمطرزين والعاملين",
  "504 - تسويق وإعلانات وممول التواصل الاجتماعي",
  "505 - مصاريف شحن وتغليف وأكياس المتجر"
];

const ACCOUNT_TYPES = ["أصول", "خصوم", "حقوق ملكية", "إيرادات", "مصاريف"];

const PAY_METHODS = ["نقد (كاش)", "حوالة بنكية", "آجل (على الحساب)"];

const INITIAL_ACCOUNTS = [
  { acc_code: "101", acc_name: "الصندوق / الخزينة الرئيسية", acc_type: "أصول", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "102", acc_name: "مخزون الأقمشة والمستلزمات", acc_type: "أصول", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "103", acc_name: "الحساب البنكي / الحوالات والمحافظ", acc_type: "أصول", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "104", acc_name: "ذمم العملاء (مستحقات خارجية)", acc_type: "أصول", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "201", acc_name: "ذمم الموردين ومحلات الأقمشة (آجل)", acc_type: "خصوم", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "301", acc_name: "رأس المال المباشر لمؤسسة Little Princesses", acc_type: "حقوق ملكية", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "401", acc_name: "إيرادات مبيعات الفساتين والزي", acc_type: "إيرادات", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "501", acc_name: "أجور ورواتب الخياطين والمطرزين", acc_type: "مصاريف", balance: 0.0, created_date: TODAY_STR_DISPLAY },
  { acc_code: "502", acc_name: "إيجار الورشة والمعمل والمحل الرئيسي", acc_type: "مصاريف", balance: 0.0, created_date: TODAY_STR_DISPLAY }
];
