function Factory({ factory, setFactory, showToast }) {
  const [formData, setFormData] = React.useState({
    order_no: '', customer: '', product: '', tailor: '', stage: FACTORY_STAGES?.[0] || 'قص', progress: '0', start_date: TODAY_STR, due_date: TODAY_STR
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.order_no) return showToast('رقم الطلب مطلوب', 'error');
    
    const newF = { id: Date.now(), ...formData };
    
    try {
      const res = await callGAS('updateFactory', newF);
      if (res.status === 'success') {
        setFactory([newF, ...factory]);
        showToast('تم تحديث حالة المشغل');
      } else showToast('حدث خطأ', 'error');
    } catch (err) {
      showToast('فشل الاتصال', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.factory} تحديث حالة المشغل</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label className="block text-sm mb-1">رقم الطلب *</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.order_no} onChange={e => setFormData({...formData, order_no: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">العميل</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.customer} onChange={e => setFormData({...formData, customer: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">المنتج</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.product} onChange={e => setFormData({...formData, product: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">الخياط/الفني</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.tailor} onChange={e => setFormData({...formData, tailor: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">المرحلة</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.stage} onChange={e => setFormData({...formData, stage: e.target.value})}>{(typeof FACTORY_STAGES !== 'undefined' ? FACTORY_STAGES : ['قص', 'خياطة', 'تطريز', 'تشطيب']).map(s => <option key={s} value={s}>{s}</option>)}</select></div>
            <div><label className="block text-sm mb-1">نسبة الإنجاز (%)</label><input type="number" min="0" max="100" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.progress} onChange={e => setFormData({...formData, progress: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">تاريخ البدء</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.start_date} onChange={e => setFormData({...formData, start_date: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">موعد التسليم</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.due_date} onChange={e => setFormData({...formData, due_date: e.target.value})} /></div>
          </div>
          <div className="flex justify-end"><button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-lg font-bold min-h-[44px]">تحديث الحالة</button></div>
        </form>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {factory.map(f => (
          <div key={f.id} className="bg-white rounded-xl shadow-sm p-4 border border-slate-200 hover:shadow-md transition-shadow">
            <div className="flex justify-between items-center mb-3">
              <span className="font-bold text-slate-800">طلب #{f.order_no}</span>
              <span className="bg-purple-100 text-purple-700 px-2 py-1 rounded-full text-xs font-bold">{f.stage}</span>
            </div>
            <div className="text-sm text-slate-600 mb-4 space-y-1">
              <p>العميل: {f.customer || '-'}</p>
              <p>المنتج: {f.product || '-'}</p>
              <p>الخياط: {f.tailor || '-'}</p>
              <p>التسليم: <span className="font-medium text-pink-600">{f.due_date}</span></p>
            </div>
            <div>
              <div className="flex justify-between text-xs mb-1"><span>الإنجاز</span><span>{f.progress}%</span></div>
              <div className="w-full bg-slate-200 rounded-full h-2">
                <div className="bg-purple-600 h-2 rounded-full" style={{width: `${f.progress}%`}}></div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
