function Dashboard({ setActiveTab }) {
  const cards = [
    {
      id: "customers",
      title: "إدارة العملاء والمقاسات",
      desc: "تسجيل بيانات العملاء ومقاسات الجسم التفصيلية",
      icon: Icons.Users,
      bgClass: "bg-purple-50/90 hover:bg-purple-100 border-purple-200 text-purple-950"
    },
    {
      id: "factory",
      title: "متابعة الورشة والإنتاج",
      desc: "إسناد المراحل للورشة ومتابعة نسب الإنجاز الخياطة",
      icon: Icons.Factory,
      bgClass: "bg-amber-50/90 hover:bg-amber-100 border-amber-200 text-amber-950"
    },
    {
      id: "purchases",
      title: "المشتريات والتوريد",
      desc: "تسديد المشتريات والربط التلقائي بمخزون أقمشة الأطفال",
      icon: Icons.Purchases,
      bgClass: "bg-indigo-50/90 hover:bg-indigo-100 border-indigo-200 text-indigo-950"
    },
    {
      id: "vouchers",
      title: "السندات والمعاملات المالية",
      desc: "إصدار السندات المالية والربط بشجرة الحسابات",
      icon: Icons.Vouchers,
      bgClass: "bg-emerald-50/90 hover:bg-emerald-100 border-emerald-200 text-emerald-950"
    }
  ];

  return (
    <div className="space-y-6 animate-fadeIn text-xs" dir="rtl">
      {/* Main Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-950 via-purple-950 to-indigo-950 text-white p-6 md:p-8 rounded-3xl shadow-xl border border-purple-800/40">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 relative z-10">
          <div>
            <span className="bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[11px] font-extrabold px-3 py-1 rounded-full inline-block mb-2">
              اللوحة التنفيذية الموحدة 👑
            </span>
            <h1 className="text-xl md:text-2xl font-black text-amber-300 leading-snug">
              مؤسسة الأميرات الصغيرات - المتخصصة في أزياء الأطفال
            </h1>
            <p className="text-xs md:text-sm text-purple-200 mt-1.5 font-semibold">
              إدارة العمليات الإنتاجية والمحاسبية والمقاسات الذكية
            </p>
          </div>

          <div className="flex items-center gap-2.5 bg-white/10 backdrop-blur-md border border-white/15 px-4 py-3 rounded-2xl text-xs font-black text-amber-200 shadow-inner shrink-0 min-h-[44px]">
            {Icons.Calendar()}
            <span>تاريخ اليوم: {TODAY_STR_DISPLAY}</span>
          </div>
        </div>
      </div>

      {/* Refined Quick Access Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-5">
        {cards.map((card) => (
          <div
            key={card.id}
            onClick={() => setActiveTab(card.id)}
            className={`group cursor-pointer p-5 rounded-3xl border shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col justify-between space-y-4 ${card.bgClass}`}
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-2xl bg-white shadow-sm group-hover:scale-110 transition-transform">
                  {typeof card.icon === 'function' ? card.icon() : card.icon}
                </div>
              </div>

              <h3 className="text-base font-black text-slate-900 group-hover:text-rose-950 transition-colors leading-snug">
                {card.title}
              </h3>
              <p className="text-[11.5px] font-medium text-slate-600 mt-1.5 leading-relaxed">
                {card.desc}
              </p>
            </div>

            <div className="pt-3 border-t border-slate-200/80 flex items-center justify-between text-xs font-black text-rose-700">
              <span className="inline-flex items-center gap-1.5 group-hover:text-rose-900 transition-colors">
                الانتقال للقسم ←
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
