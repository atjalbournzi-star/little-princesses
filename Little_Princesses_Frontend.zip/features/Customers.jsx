
// ============================================================
// Customers.jsx - قسم العملاء والمقاسات والحسابات
// Three integrated sections: Info + Measurements + Ledger
// ============================================================

function Customers({ customers = [], setCustomers, showToast }) {

  // ── توليد Customer ID تلقائياً ──
  const genCustId = () => {
    const lastNum = (customers || []).reduce((acc, c) => {
      const match = String(c.customer_id || '').match(/CUST-(\d+)/);
      return match ? Math.max(acc, parseInt(match[1])) : acc;
    }, 1000);
    return `CUST-${lastNum + 1}`;
  };

  // ── حالات القسم الأول: بيانات العميل ──
  const [custId]      = useState(genCustId);
  const [name, setName]           = useState('');
  const [phone, setPhone]         = useState('');
  const [phoneAlt, setPhoneAlt]   = useState('');
  const [platform, setPlatform]   = useState('واتساب (WhatsApp)');
  const [handle, setHandle]       = useState('');
  const [city, setCity]           = useState('');
  const [street, setStreet]       = useState('');
  const [category, setCategory]   = useState('جديد');
  const [regDate, setRegDate]     = useState(TODAY_STR_ISO);
  const [notes, setNotes]         = useState('');

  // ── حالات القسم الثاني: مقاسات الأطفال (متعددة) ──

  const isOlderThan90Days = (dateStr) => {
    if (!dateStr) return false;
    const diff = (new Date() - new Date(dateStr)) / (1000 * 60 * 60 * 24);
    return diff > 90;
  };

  const emptyMeasurement = () => ({
    id: Date.now() + Math.floor(Math.random() * 999),
    child_name: '',
    event_date: '',
    meas_date: TODAY_STR_ISO,
    unit: 'سم',
    total_height: '',
    dress_length: '',
    chest_length: '',
    skirt_length: '',
    sleeve_length: '',
    chest_circ: '',
    waist_circ: '',
    shoulder_width: '',
    armhole_circ: '',
    neck_circ: '',
    comfort_profile: [],
    sewing_notes: '',
    model_image: '',
    dress_color: ''
  });

  const [measurements, setMeasurements] = useState([emptyMeasurement()]);

  const addChildCard = () => {
    setMeasurements(prev => [...prev, emptyMeasurement()]);
    showToast('تمت إضافة بطاقة طفلة جديدة ➕');
  };

  const removeChildCard = (idx) => {
    if (measurements.length <= 1) return showToast('يجب أن تبقى بطاقة مقاس واحدة على الأقل ⚠️', 'error');
    setMeasurements(prev => prev.filter((_, i) => i !== idx));
  };

  const updateMeasurement = (idx, field, value) => {
    setMeasurements(prev => prev.map((m, i) => i === idx ? { ...m, [field]: value } : m));
  };

  // تحويل وحدة القياس (سم ↔ إنش)
  const toggleUnit = (idx) => {
    const m = measurements[idx];
    const factor = m.unit === 'سم' ? (1 / 2.54) : 2.54;
    const fields = ['total_height','dress_length','chest_length','skirt_length','sleeve_length','chest_circ','waist_circ','shoulder_width','armhole_circ','neck_circ'];
    const updated = { ...m, unit: m.unit === 'سم' ? 'إنش' : 'سم' };
    fields.forEach(f => {
      if (m[f] !== '' && !isNaN(parseFloat(m[f]))) {
        updated[f] = (parseFloat(m[f]) * factor).toFixed(1);
      }
    });
    setMeasurements(prev => prev.map((item, i) => i === idx ? updated : item));
  };

  // ── حالات القسم الثالث: كشف الحساب ──
  const [totalSales, setTotalSales]     = useState('');
  const [totalPaid, setTotalPaid]       = useState('');
  const [deposit, setDeposit]           = useState('');
  const [payMethod, setPayMethod]       = useState('نقد (كاش)');
  const [receiptFile, setReceiptFile]   = useState(null);
  const [receiptPreview, setReceiptPreview] = useState(null);
  const [delivery, setDelivery]         = useState('');

  const remaining = (() => {
    const s = Number(totalSales) || 0;
    const c = Number(delivery) || 0;
    const d = Number(deposit) || 0;
    return (s + c) > 0 ? ((s + c) - d).toFixed(2) : '';
  })();

  const handleReceiptChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setReceiptFile(ev.target.result); // base64
      setReceiptPreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  };

  // ── حالة الحفظ وعرض السجلات ──
  const [loading, setLoading] = useState(false);
  const [search, setSearch]   = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [selectedJobCard, setSelectedJobCard] = useState(null);

  // ── دالة الحفظ الرئيسية ──
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name.trim()) return showToast('اسم العميلة مطلوب ⚠️', 'error');
    if (!phone.trim()) return showToast('رقم الهاتف مطلوب ⚠️', 'error');
    setLoading(true);

    const payload = {
      customer_id:     custId,
      name:            name.trim(),
      phone:           phone.trim(),
      phone_alt:       phoneAlt.trim(),
      platform,
      handle:          handle.trim(),
      city:            city.trim(),
      street:          street.trim(),
      category,
      reg_date:        regDate,
      purchase_count:  0,
      items_count:     0,
      notes:           notes.trim(),
      measurements:    measurements.map((m, idx) => ({...m, child_name: m.child_name.trim() || 'طفلة ' + (idx + 1)})),
      ledger: {
        total_sales:   parseFloat(totalSales) || 0,
        total_paid:    parseFloat(totalPaid) || 0,
        deposit:       parseFloat(deposit) || 0,
        pay_method:    payMethod,
        receipt_b64:   receiptFile || '',
        remaining:     Number(remaining) || 0,
        delivery:      Number(delivery) || 0,
        updated_at:    TODAY_STR_ISO
      }
    };

    try {
      const response = await callGAS('addCustomer', payload);
      const newRecord = (response && response.data) ? response.data : { ...payload, id: custId };
      if (setCustomers) setCustomers(prev => [newRecord, ...(prev || [])]);
      
      showToast(`✅ تم حفظ بيانات ${name} سحابياً في Google Sheets 👑`);

    } catch (err) {
      console.error(err);
      const localRecord = { ...payload, id: custId };
      if (setCustomers) setCustomers(prev => [localRecord, ...(prev || [])]);
      showToast('تم الحفظ محلياً ⚡ — يُرجى مراجعة الاتصال', 'warning');
    } finally {
      setLoading(false);
      // إعادة تهيئة النموذج
      setName(''); setPhone(''); setPhoneAlt(''); setHandle('');
      setCity(''); setStreet(''); setNotes('');
      setTotalSales(''); setTotalPaid(''); setDeposit(''); setDelivery('');
      setReceiptFile(null); setReceiptPreview(null);
      setMeasurements([emptyMeasurement()]);
    }
  };

  // ── فلترة قائمة العملاء ──
  const filtered = (customers || []).filter(c =>
    !search || (c.name || '').includes(search) || (c.phone || '').includes(search) || (c.customer_id || '').includes(search)
  );

  const catColor = (cat) => ({
    'جديد': 'bg-blue-100 text-blue-700 border-blue-300',
    'دائم': 'bg-emerald-100 text-emerald-700 border-emerald-300',
    'VIP':  'bg-amber-100 text-amber-700 border-amber-300'
  }[cat] || 'bg-slate-100 text-slate-600');

  const inputCls = "w-full p-3 rounded-2xl border border-slate-200 bg-slate-50 text-xs font-semibold focus:bg-white focus:border-rose-300 focus:ring-1 focus:ring-rose-200 transition outline-none min-h-[42px]";
  const labelCls = "block text-[11px] font-extrabold text-slate-700 mb-1";

  return (
    <div className="space-y-5 animate-fadeIn">

      <form onSubmit={handleSubmit} className="space-y-5">

        {/* ══════════════════════════════════════════
            🟣 البطاقة الأولى: بيانات العميل الأساسية
            ══════════════════════════════════════════ */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="bg-gradient-to-l from-rose-700 to-rose-900 px-5 py-3.5 flex items-center justify-between">
            <h2 className="text-white font-black text-xs flex items-center gap-2">
              👤 بيانات العميلة الأساسية
              <span className="text-[10px] bg-white/20 rounded-full px-2 py-0.5 font-bold">{custId}</span>
            </h2>
            <span className="text-[10px] text-rose-200 font-bold">* الحقول الإلزامية</span>
          </div>

          <div className="p-5 space-y-4">
            {/* الصف الأول */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              <div>
                <label className={labelCls}>اسم العميل (الأب / الأم) <span className="text-rose-600">*</span></label>
                <input required value={name} onChange={e => setName(e.target.value)} className={inputCls} placeholder="مثال: أم محمد الأهدل" />
              </div>
              <div>
                <label className={labelCls}>الهاتف الرئيسي (واتساب) <span className="text-rose-600">*</span></label>
                <div className="relative">
                  <input required value={phone} onChange={e => setPhone(e.target.value)} className={inputCls + " pr-10 pl-2"} placeholder="77XXXXXXX" type="tel" dir="ltr" style={{textAlign:'right'}} />
                  {phone && (
                    <a href={`https://wa.me/${String(phone).replace(/^0+/, '967').replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" 
                       className="absolute right-1.5 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-emerald-100 hover:bg-emerald-200 text-emerald-600 rounded-xl transition" title="مراسلة واتساب">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    </a>
                  )}
                </div>
              </div>
              <div>
                <label className={labelCls}>الهاتف البديل الخطي</label>
                <input value={phoneAlt} onChange={e => setPhoneAlt(e.target.value)} className={inputCls} placeholder="71XXXXXXX (اختياري)" type="tel" />
              </div>
              <div>
                <label className={labelCls}>منصة التواصل الاجتماعي</label>
                <select value={platform} onChange={e => setPlatform(e.target.value)} className={inputCls}>
                  {['واتساب (WhatsApp)','انستغرام (Instagram)','فيسبوك (Facebook)','تيك توك (TikTok)','سناب شات (Snapchat)','تليجرام (Telegram)','مباشر / زيارة المحل'].map(p => (
                    <option key={p} value={p}>{p}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className={labelCls}>اسم الحساب / المعرف</label>
                <input value={handle} onChange={e => setHandle(e.target.value)} className={inputCls} placeholder="@username" />
              </div>
              <div>
                <label className={labelCls}>فئة العميل (CRM)</label>
                <select value={category} onChange={e => setCategory(e.target.value)} className={inputCls}>
                  {['جديد','دائم','VIP'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className={labelCls}>المدينة / المنطقة</label>
                <input value={city} onChange={e => setCity(e.target.value)} className={inputCls} placeholder="مثال: صنعاء - حدة" />
              </div>
              <div>
                <label className={labelCls}>الشارع / المبنى</label>
                <input value={street} onChange={e => setStreet(e.target.value)} className={inputCls} placeholder="مثال: شارع الستين - بناية الأمين" />
              </div>
              <div>
                <label className={labelCls}>تاريخ التسجيل</label>
                <input type="date" value={regDate} onChange={e => setRegDate(e.target.value)} className={inputCls} />
              </div>
            </div>
            <div>
              <label className={labelCls}>ملاحظات إضافية</label>
              <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={2} className={inputCls + " resize-none"} placeholder="أي ملاحظات خاصة بالعميلة أو تفضيلاتها..." />
            </div>
          </div>
        </div>

        {/* ══════════════════════════════════════════
            📏 البطاقة الثانية: مقاسات الأطفال
            ══════════════════════════════════════════ */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="bg-gradient-to-l from-violet-700 to-violet-900 px-5 py-3.5 flex items-center justify-between">
            <h2 className="text-white font-black text-xs">📏 مقاسات الأطفال (بطاقات متعددة)</h2>
            <button type="button" onClick={addChildCard}
              className="text-[11px] bg-white/20 hover:bg-white/30 text-white font-bold px-3 py-1.5 rounded-xl border border-white/30 transition flex items-center gap-1">
              ➕ إضافة طفلة
            </button>
          </div>

          <div className="p-5 space-y-4">
            {measurements.map((m, idx) => (
              <div key={m.id} className="border border-violet-200 rounded-2xl overflow-hidden">
                {/* رأس بطاقة الطفلة */}
                <div className="bg-violet-50 px-4 py-2.5 flex items-center justify-between">
                  <span className="text-[11px] font-black text-violet-800">
                    👧 طفلة {idx + 1}{m.child_name ? `: ${m.child_name}` : ''}
                  </span>
                  {isOlderThan90Days(m.meas_date) && (
                    <span className="text-[9px] bg-red-100 text-red-600 px-2 py-0.5 rounded-full font-bold ml-2">
                      ⚠️ أكثر من 90 يوم
                    </span>
                  )}

                  <div className="flex items-center gap-2">
                    <button type="button" onClick={() => toggleUnit(idx)}
                      className="text-[10px] bg-violet-600 text-white px-2.5 py-1 rounded-lg font-bold hover:bg-violet-700 transition">
                      تحويل → {m.unit === 'سم' ? 'إنش' : 'سم'}
                    </button>
                    {measurements.length > 1 && (
                      <button type="button" onClick={() => removeChildCard(idx)}
                        className="text-[10px] bg-red-100 text-red-600 px-2.5 py-1 rounded-lg font-bold hover:bg-red-200 transition">
                        🗑 حذف
                      </button>
                    )}
                  </div>
                </div>

                <div className="p-4 space-y-3">
                  {/* معلومات الطفلة */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    <div>
                      <label className={labelCls}>اسم الطفلة <span className="text-rose-600">*</span></label>
                      <input value={m.child_name} onChange={e => updateMeasurement(idx,'child_name',e.target.value)} className={inputCls} placeholder="مثال: لين" />
                    </div>
                    <div>
                      <label className={labelCls}>تاريخ أخذ المقاس</label>
                      <input type="date" value={m.meas_date} onChange={e => updateMeasurement(idx,'meas_date',e.target.value)} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>تاريخ المناسبة / التسليم</label>
                      <input type="date" value={m.event_date} onChange={e => updateMeasurement(idx,'event_date',e.target.value)} className={inputCls} />
                    </div>
                    <div>
                      <label className={labelCls}>لون الفستان المختار</label>
                      <input type="text" value={m.dress_color || ''} onChange={e => updateMeasurement(idx,'dress_color',e.target.value)} className={inputCls} placeholder="مثال: أحمر / كحلي" />
                    </div>
                    <div className="col-span-1 sm:col-span-2 lg:col-span-2">
                      <label className={labelCls}>صورة الموديل (اختياري)</label>
                      <div className="flex gap-2 items-center">
                        <input type="file" accept="image/*" onChange={(e) => {
                          const file = e.target.files[0];
                          if(file) {
                            const reader = new FileReader();
                            reader.onload = (ev) => updateMeasurement(idx, 'model_image', ev.target.result);
                            reader.readAsDataURL(file);
                          }
                        }} className="block w-full text-xs text-slate-500 file:mr-4 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 border border-slate-200 rounded-lg p-1 bg-white cursor-pointer" />
                        {m.model_image && <img src={m.model_image} alt="معاينة" className="w-10 h-10 object-cover rounded shadow-sm border border-slate-200" />}
                      </div>
                    </div>
                  </div>

                  {/* المقاسات الطولية */}
                  <div>
                    <p className="text-[10px] font-black text-slate-500 mb-2 flex items-center gap-1">📐 المقاسات الطولية ({m.unit})</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                      {[
                        ['total_height','الطول الكلي للطفلة'],
                        ['dress_length','طول الفستان الكلي'],
                        ['chest_length','طول الصدر'],
                        ['skirt_length','طول التنورة'],
                        ['sleeve_length','طول الكم']
                      ].map(([field, lbl]) => (
                        <div key={field}>
                          <label className={labelCls}>{lbl}</label>
                          <input type="number" step="0.1" value={m[field]} onChange={e => updateMeasurement(idx,field,e.target.value)} className={inputCls} placeholder="0" />
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* المقاسات العرضية والمحيطية */}
                  <div>
                    <p className="text-[10px] font-black text-slate-500 mb-2 flex items-center gap-1">🔄 المقاسات المحيطية ({m.unit})</p>
                    <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
                      {[
                        ['chest_circ','محيط الصدر (Chest)'],
                        ['waist_circ','محيط الخصر (Waist)'],
                        ['shoulder_width','عرض الكتفين (Shoulder)'],
                        ['armhole_circ','محيط الإبط (Armhole)'],
                        ['neck_circ','محيط الرقبة (Neck)']
                      ].map(([field, lbl]) => (
                        <div key={field}>
                          <label className={labelCls}>{lbl}</label>
                          <input type="number" step="0.1" value={m[field]} onChange={e => updateMeasurement(idx,field,e.target.value)} className={inputCls} placeholder="0" />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
                    {/* Comfort Profile */}
                    <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4">
                      <label className="block text-xs font-bold text-indigo-900 mb-3 flex items-center gap-2">تفضيلات الراحة والأقمشة (اختيار متعدد)</label>
                      <div className="flex flex-wrap gap-2">
                        {['حساسية من التل', 'بطانة قطن ناعم', 'فتحة سحاب مخفي', 'كشكشة مضاعفة'].map(pref => (
                          <label key={pref} className="flex items-center gap-2 cursor-pointer bg-white px-2 py-1 rounded-lg border border-indigo-200 hover:bg-indigo-50 transition-colors">
                            <input type="checkbox" className="rounded text-indigo-600 focus:ring-indigo-500 w-3.5 h-3.5" 
                              checked={(m.comfort_profile || []).includes(pref)}
                              onChange={(e) => {
                                const current = m.comfort_profile || [];
                                const updated = e.target.checked ? [...current, pref] : current.filter(p => p !== pref);
                                updateMeasurement(idx, 'comfort_profile', updated);
                              }}
                            />
                            <span className="text-[10px] text-indigo-800 font-medium">{pref}</span>
                          </label>
                        ))}
                      </div>
                    </div>

                    {/* Sewing Notes */}
                    <div className="bg-amber-50 border border-amber-100 rounded-xl p-4 flex flex-col">
                      <label className="block text-xs font-bold text-amber-900 mb-2 flex items-center gap-2">ملاحظات الخياطة الإضافية</label>
                      <textarea 
                        className="w-full p-2 text-xs border border-amber-200 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white flex-1 resize-none" 
                        placeholder="أضف أي ملاحظات خاصة بالمعمل أو تفضيلات إضافية هنا..." 
                        value={m.sewing_notes || ''} 
                        onChange={e => updateMeasurement(idx, 'sewing_notes', e.target.value)}
                        rows={2}
                      ></textarea>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* ══════════════════════════════════════════
            💰 البطاقة الثالثة: كشف الحساب المالي
            ══════════════════════════════════════════ */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="bg-gradient-to-l from-emerald-700 to-emerald-900 px-5 py-3.5">
            <h2 className="text-white font-black text-xs">💰 كشف الحساب المالي والطلبات</h2>
          </div>

          <div className="p-5 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
              <div>
                <label className={labelCls}>إجمالي المبيعات</label>
                <input type="number" step="0.01" value={totalSales} onChange={e => setTotalSales(e.target.value)} className={inputCls} placeholder="0.00" />
              </div>
              <div>
                <label className={labelCls}>إجمالي المدفوعات</label>
                <input type="number" step="0.01" value={totalPaid} onChange={e => setTotalPaid(e.target.value)} className={inputCls} placeholder="0.00" />
              </div>
              <div>
                <label className={labelCls}>العربون المدفوع</label>
                <input type="number" step="0.01" value={deposit} onChange={e => setDeposit(e.target.value)} className={inputCls} placeholder="0.00" />
              </div>
              <div>
                <label className={labelCls}>كلفة التوصيل</label>
                <input type="number" step="0.01" value={delivery} onChange={e => setDelivery(e.target.value)} className={inputCls} placeholder="0.00" />
              </div>
              <div>
                <label className={labelCls}>المبلغ المتبقي (آلي)</label>
                <div className={`w-full p-3 rounded-2xl border min-h-[42px] font-black text-xs flex items-center justify-center ${parseFloat(remaining) > 0 ? 'bg-red-50 border-red-300 text-red-700' : 'bg-emerald-50 border-emerald-300 text-emerald-700'}`}>
                  {remaining ? `${remaining}` : '—'}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className={labelCls}>طريقة الدفع</label>
                <select value={payMethod} onChange={e => setPayMethod(e.target.value)} className={inputCls}>
                  {['نقد (كاش)','حوالة بنكية','آجل (على الحساب)','تحويل إلكتروني'].map(p => <option key={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className={labelCls}>📎 رفع صورة السند / الإيصال</label>
                <input type="file" accept="image/*" onChange={handleReceiptChange}
                  className="w-full p-2.5 rounded-2xl border border-slate-200 bg-slate-50 text-xs font-semibold cursor-pointer file:mr-2 file:text-xs file:font-bold file:text-rose-700 file:bg-rose-50 file:border-0 file:rounded-lg file:px-2 file:py-1" />
                {/* معاينة صورة السند - فورية أسفل الحقل */}
                {receiptPreview && (
                  <div className="mt-2 flex items-start gap-3 p-2 bg-white rounded-xl border border-emerald-100 shadow-sm">
                    <img src={receiptPreview} alt="معاينة السند" className="w-16 h-16 object-cover rounded-lg border-2 border-emerald-300" />
                    <div className="text-[10px] text-slate-600 font-semibold flex-1 flex flex-col justify-center h-16">
                      <p className="text-emerald-700 font-black mb-1">✅ تم الرفع</p>
                      <button type="button" onClick={() => { setReceiptFile(null); setReceiptPreview(null); }}
                        className="text-red-500 hover:underline self-start">🗑 إزالة الصورة</button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* ── زر الحفظ الرئيسي ── */}
        <button type="submit" disabled={loading}
          className="w-full py-4 rounded-3xl font-black text-sm text-white transition-all shadow-lg disabled:opacity-60"
          style={{background: loading ? '#9ca3af' : 'linear-gradient(135deg, #be123c, #7c3aed)'}}>
          {loading
            ? '⏳ جاري الحفظ في Google Sheets...'
            : `☁️ حفظ ملف العميلة بالكامل - ${measurements.length} طفلة`}
        </button>
      </form>

      {/* ══════════════════════════════════════════
          📜 سجل العملاء (تحديث لحظي)
          ══════════════════════════════════════════ */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="px-5 py-3.5 border-b flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-black text-xs text-slate-800">📋 سجل العملاء ({filtered.length} عميلة)</h3>
          <input value={search} onChange={e => setSearch(e.target.value)}
            className="p-2.5 rounded-xl border border-slate-200 bg-slate-50 text-xs font-semibold w-48 focus:outline-none focus:border-rose-300"
            placeholder="🔍 بحث بالاسم أو الهاتف..." />
        </div>

        <div className="overflow-x-auto">
          {filtered.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs font-bold">
              لا يوجد عملاء مسجلون بعد 👤
            </div>
          ) : (
            <table className="w-full text-xs">
              <thead>
                <tr className="bg-slate-50 text-slate-600 font-extrabold">
                  {['الكود','اسم العميلة','الهاتف','المنصة','المدينة','الفئة','التسجيل','الأطفال','المتبقي','الإجراءات'].map(h => (
                    <th key={h} className="px-3 py-2.5 text-right whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((c, i) => (
                  <tr key={c.id || c.customer_id || i} className="border-t hover:bg-slate-50 transition">
                    <td className="px-3 py-2.5 font-mono text-[10px] text-rose-700 font-black whitespace-nowrap">{c.customer_id || `CUST-${i+1001}`}</td>
                    <td className="px-3 py-2.5 font-bold text-slate-900 whitespace-nowrap">{c.name || '—'}</td>
                    <td className="px-3 py-2.5 text-slate-600 whitespace-nowrap">{c.phone || '—'}</td>
                    <td className="px-3 py-2.5 text-slate-500 whitespace-nowrap">{c.platform ? c.platform.split(' ')[0] : '—'}</td>
                    <td className="px-3 py-2.5 text-slate-500 whitespace-nowrap">{c.city || c.address || '—'}</td>
                    <td className="px-3 py-2.5 whitespace-nowrap">
                      <span className={`text-[10px] font-black px-2 py-0.5 rounded-full border ${catColor(c.category)}`}>{c.category || 'جديد'}</span>
                    </td>
                    <td className="px-3 py-2.5 text-slate-400 whitespace-nowrap">{c.reg_date || '—'}</td>
                    <td className="px-3 py-2.5 text-center font-bold text-violet-700 whitespace-nowrap">
                      {c.measurements && c.measurements.length > 0 ? (
                        <div className="flex flex-col gap-1 items-center">
                          {c.measurements.map((m, idx) => {
                            const isStale = m.meas_date ? isMeasurementStale(m.meas_date) : false;
                            return (
                              <span key={idx} className="bg-violet-50 px-2 py-0.5 rounded-md text-xs font-medium border border-violet-100 shadow-sm flex items-center justify-between gap-2 min-w-[80px]">
                                <span>{m.child_name || 'بدون اسم'}</span>
                                {isStale && <span title="المقاس قديم (مر عليه أكثر من 90 يوماً)" className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>}
                              </span>
                            );
                          })}
                        </div>
                      ) : '—'}
                    </td>
                    <td className={`px-3 py-2.5 text-center font-black whitespace-nowrap ${c.ledger?.remaining > 0 ? 'text-red-600' : 'text-emerald-600'}`}>
                      {c.ledger?.remaining ? `${c.ledger.remaining}` : '—'}
                    </td>
                    <td className="px-3 py-2.5 flex items-center gap-1 justify-center whitespace-nowrap">
                      <button onClick={() => setSelectedInvoice(c)} title="طباعة فاتورة مالية (PDF)" className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z"/></svg></button>
                      <button onClick={() => setSelectedJobCard(c)} title="بطاقة المعمل (Job Card)" className="p-1.5 bg-indigo-100 hover:bg-indigo-200 text-indigo-700 rounded-lg"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-3 7h3m-3 4h3m-6-4h.01M9 16h.01"></path></svg></button>
                      <a href={`https://wa.me/${String(c.phone||'').replace(/^0+/, '967').replace(/\D/g,'')}?text=${encodeURIComponent('مرحباً ' + c.name + '، إليك كشف الحساب الخاص بك من مؤسسة الأميرات الصغيرات.')}`} target="_blank" title="إرسال كشف واتساب" className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-700 rounded-lg"><svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 00-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg></a>
                      <button onClick={() => alert('سيتم تفعيل التعديل لاحقاً')} title="تعديل" className="p-1.5 bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-lg"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"/></svg></button>
                      <button onClick={() => alert('سيتم تفعيل الحذف لاحقاً')} title="حذف" className="p-1.5 bg-red-100 hover:bg-red-200 text-red-700 rounded-lg"><svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
      {selectedInvoice && ReactDOM.createPortal(
        <InvoiceModal customer={selectedInvoice} onClose={() => setSelectedInvoice(null)} />,
        document.body
      )}
      {selectedJobCard && ReactDOM.createPortal(
        <JobCardModal customer={selectedJobCard} onClose={() => setSelectedJobCard(null)} />
      , document.body)}
    </div>
  );
}


