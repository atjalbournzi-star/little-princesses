function Accounts({ accounts, setAccounts, showToast }) {
  const [formData, setFormData] = React.useState({
    code: '', name: '', type: ACCOUNT_TYPES?.[0] || 'أصول', balance: '0', created_date: TODAY_STR
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.code || !formData.name) return showToast('الكود والاسم مطلوبان', 'error');
    
    const newAccount = { id: Date.now(), acc_code: formData.code, acc_name: formData.name, code: formData.code, name: formData.name, ...formData };
    
    try {
      const res = await callGAS('addAccount', newAccount);
      if (res.status === 'success') {
        setAccounts([newAccount, ...accounts]);
        showToast('تمت إضافة الحساب بنجاح');
      } else showToast('حدث خطأ', 'error');
    } catch (err) {
      showToast('فشل الاتصال', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.briefcase} شجرة الحسابات</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div><label className="block text-sm mb-1">كود الحساب *</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.code} onChange={e => setFormData({...formData, code: e.target.value})} /></div>
            <div className="md:col-span-2"><label className="block text-sm mb-1">اسم الحساب *</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">النوع</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})}>{(typeof ACCOUNT_TYPES !== 'undefined' ? ACCOUNT_TYPES : ['أصول','خصوم','إيرادات','مصروفات']).map(t => <option key={t} value={t}>{t}</option>)}</select></div>
            <div><label className="block text-sm mb-1">الرصيد الافتتاحي</label><input type="number" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.balance} onChange={e => setFormData({...formData, balance: e.target.value})} /></div>
          </div>
          
          <div className="flex justify-end"><button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-lg font-bold min-h-[44px]">إضافة الحساب</button></div>
        </form>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-slate-50 border-b"><tr><th className="p-3">الكود</th><th className="p-3">الاسم</th><th className="p-3">النوع</th><th className="p-3">الرصيد</th><th className="p-3">التاريخ</th></tr></thead>
          <tbody>
            {accounts.map(a => {
              const code = a.acc_code || a.code || a.id;
              const name = a.acc_name || a.name || code;
              return (
                <tr key={code} className="border-b hover:bg-slate-50">
                  <td className="p-3 font-mono">{code}</td><td className="p-3 font-medium">{name}</td><td className="p-3">{a.acc_type || a.type}</td>
                  <td className="p-3 font-bold">{a.balance}</td><td className="p-3">{a.created_date}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
