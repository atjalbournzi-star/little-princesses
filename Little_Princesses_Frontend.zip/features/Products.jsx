function Products({ products = [], setProducts, inventory = [], showToast, currency }) {
  const currencyDisplay = currency?.display || "USD $";

  const [modelName, setModelName] = useState("");
  const [category, setCategory] = useState("(Princess) فستان أميرة");
  const [selectedFabric, setSelectedFabric] = useState("");
  const [yardsUsed, setYardsUsed] = useState("3.5");
  const [laborCost, setLaborCost] = useState("70.0");
  const [packagingCost, setPackagingCost] = useState("10.0");
  const [sellPrice, setSellPrice] = useState("180.0");
  const [formCurrency, setFormCurrency] = useState(currencyDisplay);
  const [calcDate, setCalcDate] = useState(TODAY_STR_ISO);

  useEffect(() => {
    if (currency?.display) {
      setFormCurrency(currency.display);
    }
  }, [currency]);

  const fabricItem = (inventory || []).find(inv => inv.item_name === selectedFabric) || (inventory || [])[0];
  const unitCost = fabricItem ? (parseFloat(fabricItem.cost_per_meter) || 12.0) : 12.0;
  const computedFabricTotal = (parseFloat(yardsUsed || 0) * unitCost);
  const computedTotalCost = computedFabricTotal + parseFloat(laborCost || 0) + parseFloat(packagingCost || 0);
  const computedProfit = parseFloat(sellPrice || 0) - computedTotalCost;

  const handleAddProduct = async (e) => {
    e.preventDefault();
    if (!modelName.trim()) return showToast("اسم الموديل مطلوب ⚠️", "error");

    const newP = {
      id: Date.now(),
      name: modelName.trim(),
      category,
      fabric_name: selectedFabric || (fabricItem ? fabricItem.item_name : "حرير فاخر"),
      yards_used: parseFloat(yardsUsed || 0),
      fabric_cost: computedFabricTotal,
      labor_cost: parseFloat(laborCost || 0),
      packaging_cost: parseFloat(packagingCost || 0),
      total_cost: computedTotalCost,
      sell_price: parseFloat(sellPrice || 0),
      currency: formCurrency,
      profit: computedProfit,
      calc_date: calcDate
    };

    if (setProducts) setProducts([newP, ...(products || [])]);

    try {
      await callGAS("addProduct", newP);
      showToast("تم إضافة وتوثيق الموديل وحساب التكلفة سحابياً ☁️🧮");
    } catch (err) {
      showToast("تم الحفظ محلياً 🧮");
    }

    setModelName("");
  };

  return (
    <div className="space-y-6 animate-fadeIn text-xs">
      <div className="bg-white p-5 md:p-7 rounded-3xl border border-slate-200/90 shadow-sm space-y-4">
        <div className="border-b pb-3 flex items-center justify-between">
          <h2 className="font-black text-sm md:text-base text-slate-900 flex items-center gap-2">
            {Icons.Calculator()} حاسبة وتكلفة موديلات أزياء الأطفال (Add New Model/Product) 🧮
          </h2>
          <span className="text-[11px] font-bold text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-200">
            * الحقول المطلوبة
          </span>
        </div>

        <form onSubmit={handleAddProduct} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">
                اسم الموديل <span className="text-rose-600 font-black">*</span>
              </label>
              <input required type="text" value={modelName} onChange={e=>setModelName(e.target.value)} className="w-full p-3.5 rounded-2xl border bg-slate-50 font-semibold min-h-[44px]" placeholder="اسم الموديل *" />
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">التصنيف</label>
              <select value={category} onChange={e=>setCategory(e.target.value)} className="w-full p-3.5 rounded-2xl border bg-slate-50 font-semibold min-h-[44px]">
                {(PRODUCT_CATEGORIES || []).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">تاريخ الحساب 📅</label>
              <input type="date" value={calcDate} onChange={e=>setCalcDate(e.target.value)} className="w-full p-3.5 rounded-2xl border bg-slate-50 font-bold text-purple-950 min-h-[44px]" />
            </div>
          </div>

          {/* Costing Fields Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 p-4 bg-amber-50/80 rounded-3xl border border-amber-200/80">
            <div>
              <label className="block font-extrabold text-amber-950 mb-1">اختر القماش المستخدم من المخزون</label>
              <select value={selectedFabric} onChange={e=>setSelectedFabric(e.target.value)} className="w-full p-3.5 rounded-2xl border bg-white font-bold text-slate-900 min-h-[44px]">
                {(inventory || []).map(inv => (
                  <option key={inv.id} value={inv.item_name}>{inv.item_name} ({inv.cost_per_meter || 12} {currencyDisplay} / متر)</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-extrabold text-amber-950 mb-1">كمية القماش المستخدمة (بالأمتار/م)</label>
              <input type="number" step="0.1" value={yardsUsed} onChange={e=>setYardsUsed(e.target.value)} className="w-full p-3.5 rounded-2xl border text-center font-black text-slate-900 min-h-[44px] bg-white" placeholder="3.5 م" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">تكلفة القماش ({currencyDisplay})</label>
              <input readOnly type="number" value={computedFabricTotal.toFixed(1)} className="w-full p-3.5 rounded-2xl border bg-slate-100 text-center font-black text-purple-950 min-h-[44px]" />
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">أجرة الخياطة والعمالة ({currencyDisplay})</label>
              <input type="number" value={laborCost} onChange={e=>setLaborCost(e.target.value)} className="w-full p-3.5 rounded-2xl border text-center font-bold min-h-[44px]" />
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">التغليف والإكسسوارات ({currencyDisplay})</label>
              <input type="number" value={packagingCost} onChange={e=>setPackagingCost(e.target.value)} className="w-full p-3.5 rounded-2xl border text-center font-bold min-h-[44px]" />
            </div>
          </div>

          {/* Pricing Summary */}
          <div className="grid grid-cols-3 gap-3.5 p-5 bg-purple-950 text-white rounded-3xl font-extrabold text-center shadow-inner">
            <div>
              <span className="block text-[11px] text-purple-200 mb-1">إجمالي التكلفة الحسابية</span>
              <span className="text-amber-300 text-sm font-black">{computedTotalCost.toFixed(1)} {currencyDisplay}</span>
            </div>
            <div>
              <label className="block text-[11px] text-purple-200 mb-1">سعر البيع المقترح ({currencyDisplay})</label>
              <input type="number" value={sellPrice} onChange={e=>setSellPrice(e.target.value)} className="w-full p-2 text-slate-900 rounded-xl text-center font-black bg-white" />
            </div>
            <div>
              <span className="block text-[11px] text-purple-200 mb-1">هامش صافي الربح</span>
              <span className="text-emerald-400 text-sm font-black">{computedProfit.toFixed(1)} {currencyDisplay}</span>
            </div>
          </div>

          <button type="submit" className="w-full py-4 min-h-[44px] bg-rose-600 hover:bg-rose-700 text-white font-black text-sm rounded-2xl shadow-md hover:shadow-lg transition-all">
            حفظ الموديل والتكلفة سحابياً ➕
          </button>
        </form>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-x-auto w-full">
        <table className="w-full text-right text-[11.5px] min-w-[750px]">
          <thead>
            <tr className="bg-slate-100 text-slate-800 font-black border-b">
              <th className="p-3.5">ID</th>
              <th className="p-3.5">اسم الموديل</th>
              <th className="p-3.5">التصنيف</th>
              <th className="p-3.5">اسم القماش</th>
              <th className="p-3.5">التكلفة الإجمالية</th>
              <th className="p-3.5">سعر البيع</th>
              <th className="p-3.5">الربح المتوقع</th>
              <th className="p-3.5">العملة</th>
            </tr>
          </thead>
          <tbody className="divide-y font-semibold">
            {(products || []).map(p => (
              <tr key={p.id} className="hover:bg-purple-50/50 transition-colors">
                <td className="p-3.5 font-bold text-purple-950">#{p.id}</td>
                <td className="p-3.5 font-black text-slate-900">{p.name}</td>
                <td className="p-3.5"><span className="bg-purple-100 text-purple-900 px-2.5 py-1 rounded-lg font-bold">{p.category}</span></td>
                <td className="p-3.5">{p.fabric_name}</td>
                <td className="p-3.5 font-bold text-slate-900">{p.total_cost} {p.currency || currencyDisplay}</td>
                <td className="p-3.5 font-black text-emerald-700">{p.sell_price} {p.currency || currencyDisplay}</td>
                <td className="p-3.5 font-black text-purple-900">+{p.profit} {p.currency || currencyDisplay}</td>
                <td className="p-3.5 font-bold">{p.currency || currencyDisplay}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
