function Journal({ journal, setJournal, accounts, showToast }) {
  const [formData, setFormData] = React.useState({
    entry_no: '', debit: '', credit: '', amount: '', currency: CURRENCIES?.[0] || 'SAR', date: TODAY_STR, notes: '', ref_type: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.debit || !formData.credit || !formData.amount) return showToast('الطرف المدين، الدائن، والمبلغ مطلوبة', 'error');
    if (formData.debit === formData.credit) return showToast('الطرف المدين والدائن يجب أن يكونا مختلفين', 'error');
    
    const newJ = { id: Date.now(), ...formData };
    
    try {
      const res = await callGAS('addJournalEntry', newJ);
      if (res.status === 'success') {
        setJournal([newJ, ...journal]);
        showToast('تم حفظ القيد بنجاح');
      } else showToast('حدث خطأ', 'error');
    } catch (err) {
      showToast('فشل الاتصال', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.briefcase} إضافة قيد يومية</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label className="block text-sm mb-1">رقم القيد</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.entry_no} onChange={e => setFormData({...formData, entry_no: e.target.value})} /></div>
            <div>
              <label className="block text-sm mb-1">من حساب (المدين) *</label>
              <select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.debit} onChange={e => setFormData({...formData, debit: e.target.value})}>
                <option value="">-- اختر حساب --</option>
                {accounts.map(a => {
                  const code = a.acc_code || a.code || a.id;
                  const name = a.acc_name || a.name || code;
                  return <option key={code} value={code}>{code} - {name}</option>;
                })}
              </select>
            </div>
            <div>
              <label className="block text-sm mb-1">إلى حساب (الدائن) *</label>
              <select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.credit} onChange={e => setFormData({...formData, credit: e.target.value})}>
                <option value="">-- اختر حساب --</option>
                {accounts.map(a => {
                  const code = a.acc_code || a.code || a.id;
                  const name = a.acc_name || a.name || code;
                  return <option key={code} value={code}>{code} - {name}</option>;
                })}
              </select>
            </div>
            <div><label className="block text-sm mb-1">المبلغ *</label><input type="number" step="0.01" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">العملة</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.currency} onChange={e => setFormData({...formData, currency: e.target.value})}>{(CURRENCIES || [currency.display, "YER ﷼", "SAR ﷼"]).map(c => <option key={typeof c === "object" ? c.value : c} value={typeof c === "object" ? c.value : c}>{typeof c === "object" ? c.label : c}</option>)}</select></div>
            <div><label className="block text-sm mb-1">التاريخ</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} /></div>
            <div className="md:col-span-2"><label className="block text-sm mb-1">البيان</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} /></div>
          </div>
          <div className="flex justify-end"><button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-lg font-bold min-h-[44px]">حفظ القيد</button></div>
        </form>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-slate-50 border-b"><tr><th className="p-3">رقم</th><th className="p-3">المدين</th><th className="p-3">الدائن</th><th className="p-3">المبلغ</th><th className="p-3">التاريخ</th><th className="p-3">البيان</th></tr></thead>
          <tbody>
            {journal.map(j => {
              const debitAcc = accounts.find(a => a.code == j.debit)?.name || j.debit;
              const creditAcc = accounts.find(a => a.code == j.credit)?.name || j.credit;
              return (
                <tr key={j.id} className="border-b hover:bg-slate-50">
                  <td className="p-3 font-medium">{j.entry_no}</td><td className="p-3">{debitAcc}</td><td className="p-3">{creditAcc}</td>
                  <td className="p-3 font-bold">{j.amount} {j.currency}</td><td className="p-3">{j.date}</td><td className="p-3">{j.notes}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
