function Vouchers({ vouchers, setVouchers, accounts, showToast }) {
  const [formData, setFormData] = React.useState({
    v_no: '', v_type: 'سند قبض', party: '', amount: '', currency: CURRENCIES?.[0] || 'SAR', date: TODAY_STR, notes: '', pay_method: PAY_METHODS?.[0] || 'نقدي', acc_code: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.party || !formData.amount) return showToast('الطرف والمبلغ مطلوبان', 'error');
    
    const newV = { id: Date.now(), ...formData };
    
    try {
      const res = await callGAS('addVoucher', newV);
      if (res.status === 'success') {
        setVouchers([newV, ...vouchers]);
        showToast('تم حفظ السند بنجاح');
      } else showToast('حدث خطأ', 'error');
    } catch (err) {
      showToast('فشل الاتصال', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.receipt} إضافة سند (قبض/صرف)</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label className="block text-sm mb-1">نوع السند</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.v_type} onChange={e => setFormData({...formData, v_type: e.target.value})}><option>سند قبض</option><option>سند صرف</option></select></div>
            <div><label className="block text-sm mb-1">رقم السند</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.v_no} onChange={e => setFormData({...formData, v_no: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">{formData.v_type === 'سند قبض' ? 'استلمنا من' : 'صرفنا إلى'} *</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.party} onChange={e => setFormData({...formData, party: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">المبلغ *</label><input type="number" step="0.01" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">العملة</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.currency} onChange={e => setFormData({...formData, currency: e.target.value})}>{(CURRENCIES || [currency.display, "YER ﷼", "SAR ﷼"]).map(c => <option key={typeof c === "object" ? c.value : c} value={typeof c === "object" ? c.value : c}>{typeof c === "object" ? c.label : c}</option>)}</select></div>
            <div><label className="block text-sm mb-1">طريقة الدفع</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.pay_method} onChange={e => setFormData({...formData, pay_method: e.target.value})}>{(typeof PAY_METHODS !== 'undefined' ? PAY_METHODS : ['نقدي']).map(p => <option key={p} value={p}>{p}</option>)}</select></div>
            <div>
              <label className="block text-sm mb-1">حساب الصندوق/البنك</label>
              <select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.acc_code} onChange={e => setFormData({...formData, acc_code: e.target.value})}>
                <option value="">-- اختر حساب --</option>
                {accounts.map(a => {
                  const code = a.acc_code || a.code || a.id;
                  const name = a.acc_name || a.name || code;
                  return <option key={code} value={code}>{code} - {name}</option>;
                })}
              </select>
            </div>
            <div><label className="block text-sm mb-1">التاريخ</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} /></div>
            <div className="md:col-span-2 lg:col-span-4"><label className="block text-sm mb-1">البيان / ملاحظات</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} /></div>
          </div>
          <div className="flex justify-end"><button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-lg font-bold min-h-[44px]">حفظ السند</button></div>
        </form>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-slate-50 border-b"><tr><th className="p-3">النوع</th><th className="p-3">الرقم</th><th className="p-3">الطرف</th><th className="p-3">المبلغ</th><th className="p-3">طريقة الدفع</th><th className="p-3">التاريخ</th></tr></thead>
          <tbody>
            {vouchers.map(v => (
              <tr key={v.id} className="border-b hover:bg-slate-50">
                <td className="p-3"><span className={`px-2 py-1 rounded-full text-xs font-bold ${v.v_type === 'سند قبض' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{v.v_type}</span></td>
                <td className="p-3">{v.v_no}</td><td className="p-3 font-medium">{v.party}</td><td className="p-3 font-bold">{v.amount} {v.currency}</td>
                <td className="p-3">{v.pay_method}</td><td className="p-3">{v.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
