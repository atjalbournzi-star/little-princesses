const Feedback = ({ feedback, setFeedback, customers, showToast }) => {
  const { useState, useMemo } = React;

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Form State
  const [formData, setFormData] = useState({
    customer_id: '',
    customer_name: '',
    order_id: '',
    overall_satisfaction: '5',
    fit_error_origin: 'بدون أخطاء',
    sewing_rating: 'ممتاز',
    delivery_rating: 'في الموعد',
    status: 'تم التقييم',
    notes: ''
  });

  const handleCustomerSelect = (e) => {
    const custId = e.target.value;
    const cust = customers.find(c => c['كود_العميل'] === custId);
    if (cust) {
      setFormData(prev => ({
        ...prev,
        customer_id: custId,
        customer_name: cust['اسم_العميل']
      }));
    } else {
      setFormData(prev => ({ ...prev, customer_id: '', customer_name: '' }));
    }
  };

  const generateWhatsAppLink = (cust, orderId) => {
    const phone = cust['الهاتف_الرئيسي'] || cust['الهاتف_السيار'] || '';
    if (!phone) {
      showToast('لا يوجد رقم هاتف مسجل للعميلة', 'error');
      return;
    }
    
    let formattedPhone = phone.trim();

    const message = `أهلاً بكِ أختي ${cust['اسم_العميل']} 🌸\nنتمنى أن تكوني بأتم الصحة والعافية.\nنود أن نسألك عن تقييمك لجودة الخياطة والمقاسات للطلب رقم (${orderId}).\nملاحظاتك تهمنا جداً لتطوير الخدمة! ✨\n- إدارة Little Princesses`;
    const encoded = encodeURIComponent(message);
    const url = `https://wa.me/${formattedPhone}?text=${encoded}`;
    window.open(url, '_blank');
  };

  const openWhatsAppFromTable = (f) => {
    const cust = customers.find(c => c['كود_العميل'] === f['كود_العميل']);
    if (cust) {
      generateWhatsAppLink(cust, f['رقم_الطلب']);
    } else {
      showToast('لم يتم العثور على بيانات العميل الأصلية لإرسال رسالة', 'error');
    }
  };

  const openWaForNew = () => {
    if (!formData.customer_id) {
      showToast('الرجاء اختيار العميل أولاً', 'error');
      return;
    }
    const cust = customers.find(c => c['كود_العميل'] === formData.customer_id);
    generateWhatsAppLink(cust, formData.order_id || '---');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.customer_id) return showToast('الرجاء تحديد العميل', 'error');
    
    setIsSubmitting(true);
    try {
      const res = await window.addFeedback(formData);
      if (res && res.success) {
        showToast('تم حفظ التقييم بنجاح!');
        const newRecord = {
          'تاريخ_التقييم': new Date().toISOString().split('T')[0],
          'كود_العميل': formData.customer_id,
          'اسم_العميل': formData.customer_name,
          'رقم_الطلب': formData.order_id,
          'درجة_الرضا_الكلية': formData.status === 'تم الاستلام - لم يتم الرد' ? 4 : formData.overall_satisfaction,
          'مصدر_خطأ_المقاسات': formData.fit_error_origin,
          'تقييم_الخياطة_والقماش': formData.sewing_rating,
          'تقييم_التوصيل': formData.delivery_rating,
          'حالة_متابعة_التقييم': formData.status,
          'ملاحظات_العميلة': formData.notes
        };
        setFeedback(prev => [...prev, newRecord]);
        setIsModalOpen(false);
        setFormData({
          customer_id: '', customer_name: '', order_id: '', overall_satisfaction: '5',
          fit_error_origin: 'بدون أخطاء', sewing_rating: 'ممتاز', delivery_rating: 'في الموعد',
          status: 'تم التقييم', notes: ''
        });
      } else {
        showToast(res.message || 'حدث خطأ أثناء الحفظ', 'error');
      }
    } catch (err) {
      showToast('خطأ في الاتصال بالخادم', 'error');
      console.error(err);
    }
    setIsSubmitting(false);
  };

  const statusColors = {
    'قيد الانتظار': 'bg-amber-100 text-amber-800',
    'تم التقييم': 'bg-emerald-100 text-emerald-800',
    'تم الاستلام - لم يتم الرد': 'bg-slate-100 text-slate-800'
  };

  return (
    <div className="space-y-6 animate-fadeIn">
      {/* Header section */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <span className="text-purple-600"><Icons.Star /></span>
            إدارة رضا العملاء وجودة الخياطة
          </h1>
          <p className="text-slate-500 mt-1">متابعة تقييمات العملاء، إدارة الأخطاء، والتواصل عبر واتساب</p>
        </div>
        <button 
          onClick={() => setIsModalOpen(true)}
          className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-2.5 rounded-xl font-medium transition-all shadow-lg shadow-purple-200 flex items-center gap-2"
        >
          <span>إضافة تقييم جديد</span>
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 border-r-4 border-r-emerald-500">
          <div className="text-sm font-medium text-slate-500 mb-1">إجمالي التقييمات</div>
          <div className="text-2xl font-bold text-slate-800">{feedback.length}</div>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 border-r-4 border-r-amber-500">
          <div className="text-sm font-medium text-slate-500 mb-1">قيد الانتظار</div>
          <div className="text-2xl font-bold text-slate-800">{feedback.filter(f => f['حالة_متابعة_التقييم'] === 'قيد الانتظار').length}</div>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 border-r-4 border-r-purple-500">
          <div className="text-sm font-medium text-slate-500 mb-1">متوسط الرضا</div>
          <div className="text-2xl font-bold text-slate-800">
            {feedback.length > 0 
              ? (feedback.reduce((sum, f) => sum + Number(f['درجة_الرضا_الكلية'] || 0), 0) / feedback.length).toFixed(1) 
              : '0'} / 5
          </div>
        </div>
        <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 border-r-4 border-r-rose-500">
          <div className="text-sm font-medium text-slate-500 mb-1">أخطاء الورشة</div>
          <div className="text-2xl font-bold text-slate-800">{feedback.filter(f => String(f['مصدر_خطأ_المقاسات']).includes('ورشة')).length}</div>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-100 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-sm">
            <thead className="bg-slate-50 border-b border-slate-100 text-slate-600 font-medium">
              <tr>
                <th className="px-6 py-4">التاريخ</th>
                <th className="px-6 py-4">العميل</th>
                <th className="px-6 py-4">الطلب</th>
                <th className="px-6 py-4">الرضا</th>
                <th className="px-6 py-4">حالة المتابعة</th>
                <th className="px-6 py-4">مصدر الخطأ</th>
                <th className="px-6 py-4">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {feedback.length === 0 ? (
                <tr>
                  <td colSpan="7" className="px-6 py-12 text-center text-slate-400">لا توجد تقييمات مسجلة حالياً</td>
                </tr>
              ) : (
                feedback.map((f, i) => (
                  <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                    <td className="px-6 py-4 text-slate-500">{String(f['تاريخ_التقييم']).split('T')[0]}</td>
                    <td className="px-6 py-4 font-medium text-slate-800">{f['اسم_العميل']}</td>
                    <td className="px-6 py-4 text-slate-600">{f['رقم_الطلب']}</td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1 text-amber-400">
                        <span className="font-bold text-slate-800">{f['درجة_الرضا_الكلية']}</span>
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${statusColors[f['حالة_متابعة_التقييم']] || 'bg-slate-100'}`}>
                        {f['حالة_متابعة_التقييم']}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      {f['مصدر_خطأ_المقاسات'] === 'بدون أخطاء' ? (
                        <span className="text-slate-400">---</span>
                      ) : (
                        <span className={`text-xs font-medium px-2 py-1 rounded ${String(f['مصدر_خطأ_المقاسات']).includes('ورشة') ? 'bg-rose-50 text-rose-600' : 'bg-blue-50 text-blue-600'}`}>
                          {f['مصدر_خطأ_المقاسات']}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <button onClick={() => openWhatsAppFromTable(f)} className="text-emerald-500 hover:text-emerald-600 transition-colors" title="طلب تقييم عبر واتساب">
                        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.182-.573c.978.58 1.711.927 2.806.928 3.18 0 5.766-2.585 5.769-5.766.002-3.181-2.585-5.769-5.766-5.769l-.34.001zm0 1.258c2.485 0 4.509 2.024 4.51 4.51.001 2.484-2.023 4.508-4.508 4.509-1.077 0-1.898-.445-2.616-.948l-.183-.128-1.5.393.398-1.463-.14-.194c-.45-.635-.783-1.488-.783-2.515.001-2.486 2.025-4.51 4.51-4.51l.312-.004zm-1.895 2.182c-.08-.002-.204.015-.313.065-.187.086-.467.284-.6.643-.133.358-.168.852.12 1.543.25.602.822 1.34 1.558 1.954 1.096.91 2.046 1.18 2.628 1.353.486.146.732.115.932.062.275-.073.652-.293.811-.643.16-.35.16-.644.113-.706-.048-.063-.162-.098-.31-.173-.15-.075-.89-.441-1.028-.491-.138-.051-.238-.076-.339.076-.1.15-.389.492-.477.592-.087.1-.174.113-.325.037-.15-.075-.635-.235-1.21-.749-.446-.4-.748-.895-.836-1.045-.088-.151-.01-.233.065-.308.067-.067.15-.175.225-.262.075-.088.1-.15.15-.25.05-.1.025-.188-.013-.262-.038-.075-.338-.816-.463-1.117-.122-.294-.246-.254-.338-.258-.088-.005-.189-.006-.29-.007z"/></svg>
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
              <h2 className="text-xl font-bold text-slate-800">إضافة تقييم جديد</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600">
                <Icons.Close />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto no-scrollbar">
              <form id="feedbackForm" onSubmit={handleSubmit} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  
                  {/* العميل */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">العميل</label>
                    <select 
                      required
                      value={formData.customer_id}
                      onChange={handleCustomerSelect}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    >
                      <option value="">-- اختر العميل --</option>
                      {customers.map(c => (
                        <option key={c['كود_العميل']} value={c['كود_العميل']}>{c['اسم_العميل']}</option>
                      ))}
                    </select>
                  </div>

                  {/* رقم الطلب */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">رقم الطلب (اختياري)</label>
                    <input 
                      type="text"
                      value={formData.order_id}
                      onChange={e => setFormData({...formData, order_id: e.target.value})}
                      placeholder="رقم الفاتورة أو الطلب"
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    />
                  </div>
                  
                  {/* الواتساب الذكي */}
                  <div className="md:col-span-2 bg-emerald-50 border border-emerald-100 rounded-xl p-4 flex items-center justify-between">
                    <div>
                      <h4 className="font-semibold text-emerald-800">رابط تقييم واتساب</h4>
                      <p className="text-sm text-emerald-600 mt-1">توليد رسالة طلب تقييم جاهزة ومباشرة للعميلة</p>
                    </div>
                    <button type="button" onClick={openWaForNew} className="bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors">
                      إرسال واتساب
                    </button>
                  </div>

                  {/* حالة المتابعة */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">حالة التقييم والمتابعة</label>
                    <select 
                      value={formData.status}
                      onChange={e => setFormData({...formData, status: e.target.value})}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    >
                      <option value="قيد الانتظار">قيد الانتظار (تم الإرسال)</option>
                      <option value="تم التقييم">تم التقييم (تم استلام الرد)</option>
                      <option value="تم الاستلام - لم يتم الرد">تم الاستلام - لم يتم الرد (رضا ضمني)</option>
                    </select>
                    {formData.status === 'تم الاستلام - لم يتم الرد' && (
                      <p className="text-xs text-amber-600 mt-1">سيتم احتساب 4/5 تلقائياً كرضا ضمني للحفاظ على مؤشرات الأداء.</p>
                    )}
                  </div>

                  {/* التقييم العام */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">التقييم العام (من 5)</label>
                    <input 
                      type="number" min="1" max="5" step="0.5"
                      disabled={formData.status === 'تم الاستلام - لم يتم الرد'}
                      value={formData.overall_satisfaction}
                      onChange={e => setFormData({...formData, overall_satisfaction: e.target.value})}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none disabled:opacity-50"
                    />
                  </div>

                  {/* تقييم الخياطة */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">تقييم الخياطة والتشطيب</label>
                    <select 
                      value={formData.sewing_rating}
                      onChange={e => setFormData({...formData, sewing_rating: e.target.value})}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    >
                      <option>ممتاز</option>
                      <option>جيد جداً</option>
                      <option>مقبول (يوجد ملاحظات)</option>
                      <option>سيء</option>
                    </select>
                  </div>

                  {/* التوصيل */}
                  <div className="space-y-2">
                    <label className="text-sm font-semibold text-slate-700">التغليف وموعد التسليم</label>
                    <select 
                      value={formData.delivery_rating}
                      onChange={e => setFormData({...formData, delivery_rating: e.target.value})}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    >
                      <option>في الموعد - ممتاز</option>
                      <option>تأخير بسيط</option>
                      <option>تأخير كبير</option>
                      <option>مشكلة في التغليف</option>
                    </select>
                  </div>

                  {/* مصدر خطأ المقاسات */}
                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-semibold text-slate-700">تحليل أخطاء المقاسات (إن وُجدت)</label>
                    <select 
                      value={formData.fit_error_origin}
                      onChange={e => setFormData({...formData, fit_error_origin: e.target.value})}
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    >
                      <option value="بدون أخطاء">بدون أخطاء (المقاس مضبوط)</option>
                      <option value="خطأ من الورشة (تذكرة صيانة مجانية)">خطأ من الورشة (يستوجب صيانة مجانية فورية)</option>
                      <option value="خطأ من العميلة (تعديل بخصم رمزي)">خطأ أرسلته العميلة (يستوجب التعديل بخصم رمزي)</option>
                    </select>
                  </div>

                  <div className="md:col-span-2 space-y-2">
                    <label className="text-sm font-semibold text-slate-700">ملاحظات إضافية</label>
                    <textarea 
                      rows="3"
                      value={formData.notes}
                      onChange={e => setFormData({...formData, notes: e.target.value})}
                      placeholder="أي ملاحظات من العميلة..."
                      className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500 outline-none"
                    ></textarea>
                  </div>

                </div>
              </form>
            </div>
            
            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
              <button 
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="px-6 py-2.5 rounded-xl font-medium text-slate-600 hover:bg-slate-200 transition-colors"
              >
                إلغاء
              </button>
              <button 
                type="submit"
                form="feedbackForm"
                disabled={isSubmitting}
                className="bg-purple-600 hover:bg-purple-700 disabled:bg-purple-400 text-white px-8 py-2.5 rounded-xl font-medium transition-colors"
              >
                {isSubmitting ? 'جاري الحفظ...' : 'حفظ التقييم'}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
