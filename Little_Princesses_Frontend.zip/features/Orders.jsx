function Orders({ orders = [], setOrders, customers = [], products = [], showToast, currency }) {
  const currencyDisplay = currency?.display || "USD $";

  const [customerName, setCustomerName] = useState("");
  const [productName, setProductName] = useState("");
  const [qty, setQty] = useState("1");
  const [total, setTotal] = useState("180");
  const [paid, setPaid] = useState("100");
  const [formCurrency, setFormCurrency] = useState(currencyDisplay);
  const [orderDate, setOrderDate] = useState(TODAY_STR_ISO);
  const [deliveryDate, setDeliveryDate] = useState(TODAY_STR_ISO);

  useEffect(() => {
    if (currency?.display) {
      setFormCurrency(currency.display);
    }
  }, [currency]);

  const handleSaveInvoice = async (e) => {
    e.preventDefault();
    if (!customerName || !productName) return showToast("يرجى اختيار العميلة والمنتج ⚠️", "error");

    const tot = parseFloat(total || 0);
    const pd = parseFloat(paid || 0);
    const newOrd = {
      id: Date.now(),
      order_no: `ORD-${Date.now().toString().slice(-4)}`,
      customer_name: customerName,
      product_name: productName,
      qty: parseInt(qty || 1),
      order_date: orderDate,
      delivery_date: deliveryDate,
      total: tot,
      paid: pd,
      remaining: tot - pd,
      currency: formCurrency,
      status: "قيد الخياطة 🪡"
    };

    if (setOrders) setOrders([newOrd, ...(orders || [])]);

    try {
      await callGAS("addOrder", newOrd);
      showToast("تم إصدار وحفظ الفاتورة سحابياً وتوليد QR بنجاح ☁️📄");
    } catch (err) {
      showToast("تم الحفظ محلياً 📄");
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn text-xs">
      <div className="bg-white p-5 md:p-7 rounded-3xl border border-slate-200/90 shadow-sm space-y-4">
        <div className="border-b pb-3 flex items-center justify-between">
          <h2 className="font-black text-sm md:text-base text-slate-900 flex items-center gap-2">
            {Icons.ShoppingBag()} حجز فستان / إصدار فاتورة جديدة (Add New Order) 📄
          </h2>
        </div>

        <form onSubmit={handleSaveInvoice} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">اختر العميلة من السجل</label>
              <select value={customerName} onChange={e=>setCustomerName(e.target.value)} className="w-full p-3.5 rounded-2xl border bg-slate-50 font-bold min-h-[44px]">
                <option value="">-- Select Customer / اختر العميلة --</option>
                {(customers || []).map(c => <option key={c.id} value={c.name}>{c.name} ({c.phone || 'بدون هاتف'})</option>)}
              </select>
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">اختر الفستان / الموديل</label>
              <select value={productName} onChange={e=>setProductName(e.target.value)} className="w-full p-3.5 rounded-2xl border bg-slate-50 font-bold min-h-[44px]">
                <option value="">-- Select Product / اختر الفستان --</option>
                {(products || []).map(p => <option key={p.id} value={p.name}>{p.name} ({p.sell_price} {currencyDisplay})</option>)}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">تاريخ الفاتورة/الحجز 📅</label>
              <input type="date" value={orderDate} onChange={e=>setOrderDate(e.target.value)} className="w-full p-3.5 rounded-2xl border font-bold text-purple-950 min-h-[44px]" />
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">موعد التسليم المتوقع 📅</label>
              <input type="date" value={deliveryDate} onChange={e=>setDeliveryDate(e.target.value)} className="w-full p-3.5 rounded-2xl border font-bold text-sky-950 min-h-[44px]" />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">الكمية (عدد)</label>
              <input type="number" min="1" value={qty} onChange={e=>setQty(e.target.value)} className="w-full p-3.5 rounded-2xl border text-center font-extrabold min-h-[44px]" />
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">الإجمالي الكلي ({currencyDisplay})</label>
              <input type="number" value={total} onChange={e=>setTotal(e.target.value)} className="w-full p-3.5 rounded-2xl border text-center font-black text-slate-900 min-h-[44px]" placeholder="الإجمالي" />
            </div>
            <div>
              <label className="block font-extrabold text-slate-800 mb-1">المدفوع / العربون ({currencyDisplay})</label>
              <input type="number" value={paid} onChange={e=>setPaid(e.target.value)} className="w-full p-3.5 rounded-2xl border text-center font-black text-emerald-700 min-h-[44px]" placeholder="العربون" />
            </div>
          </div>

          <button type="submit" className="w-full py-4 min-h-[44px] bg-rose-600 hover:bg-rose-700 text-white font-black text-sm rounded-2xl shadow-md hover:shadow-lg transition-all">
            حفظ الفاتورة وتوليد QR Code سحابياً 📄
          </button>
        </form>
      </div>

      {/* Orders Table */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-x-auto w-full">
        {(!orders || orders.length === 0) ? (
          <div className="p-12 text-center text-slate-400 font-bold space-y-2">
            <span className="text-3xl block">📄</span>
            <p className="text-sm">No Orders Yet / لا توجد طلبات مسجلة بعد</p>
          </div>
        ) : (
          <table className="w-full text-right text-[11.5px] min-w-[700px]">
            <thead>
              <tr className="bg-slate-100 text-slate-800 font-black border-b">
                <th className="p-3.5">Order ID</th>
                <th className="p-3.5">Customer / العميلة</th>
                <th className="p-3.5">Product / الفستان</th>
                <th className="p-3.5">Quantity / العدد</th>
                <th className="p-3.5">Total / الإجمالي</th>
                <th className="p-3.5">Remaining / المتبقي</th>
                <th className="p-3.5">Delivery Date / التسليم</th>
                <th className="p-3.5">Status / الحالة</th>
              </tr>
            </thead>
            <tbody className="divide-y font-semibold">
              {orders.map(o => (
                <tr key={o.id} className="hover:bg-rose-50/40 transition-colors">
                  <td className="p-3.5 font-bold text-rose-950">{o.order_no}</td>
                  <td className="p-3.5 font-black text-slate-900">{o.customer_name}</td>
                  <td className="p-3.5 font-bold">{o.product_name}</td>
                  <td className="p-3.5 font-bold text-center">{o.qty}</td>
                  <td className="p-3.5 font-black text-slate-900">{o.total} {o.currency || currencyDisplay}</td>
                  <td className="p-3.5 font-black text-rose-700">{(o.total || 0) - (o.paid || 0)} {o.currency || currencyDisplay}</td>
                  <td className="p-3.5 text-amber-900 font-bold">{formatDateDisplay(o.delivery_date)}</td>
                  <td className="p-3.5"><span className="bg-amber-100 text-amber-900 px-2.5 py-1 rounded-xl font-bold">{o.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
