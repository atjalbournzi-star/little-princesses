function Expenses({ expenses, setExpenses, accounts, showToast }) {
  const [formData, setFormData] = React.useState({
    exp_category: EXPENSE_CATEGORIES?.[0] || 'مصروفات تشغيل', amount: '', currency: CURRENCIES?.[0] || 'SAR', date: TODAY_STR, notes: '', pay_method: PAY_METHODS?.[0] || 'نقدي', source_acc: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.amount) return showToast('المبلغ مطلوب', 'error');
    
    const newE = { id: Date.now(), ...formData };
    
    try {
      const res = await callGAS('addExpense', newE);
      if (res.status === 'success') {
        setExpenses([newE, ...expenses]);
        showToast('تم حفظ المصروف بنجاح');
      } else showToast('حدث خطأ', 'error');
    } catch (err) {
      showToast('فشل الاتصال', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.briefcase} تسجيل مصروف جديد</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div><label className="block text-sm mb-1">بند المصروف</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.exp_category} onChange={e => setFormData({...formData, exp_category: e.target.value})}>{(typeof EXPENSE_CATEGORIES !== 'undefined' ? EXPENSE_CATEGORIES : ['إيجار','كهرباء']).map(c => <option key={c} value={c}>{c}</option>)}</select></div>
            <div><label className="block text-sm mb-1">المبلغ *</label><input type="number" step="0.01" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.amount} onChange={e => setFormData({...formData, amount: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">العملة</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.currency} onChange={e => setFormData({...formData, currency: e.target.value})}>{(CURRENCIES || [currency.display, "YER ﷼", "SAR ﷼"]).map(c => <option key={typeof c === "object" ? c.value : c} value={typeof c === "object" ? c.value : c}>{typeof c === "object" ? c.label : c}</option>)}</select></div>
            <div><label className="block text-sm mb-1">طريقة الدفع</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.pay_method} onChange={e => setFormData({...formData, pay_method: e.target.value})}>{(typeof PAY_METHODS !== 'undefined' ? PAY_METHODS : ['نقدي']).map(p => <option key={p} value={p}>{p}</option>)}</select></div>
            <div>
              <label className="block text-sm mb-1">حساب الدفع</label>
              <select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.source_acc} onChange={e => setFormData({...formData, source_acc: e.target.value})}>
                <option value="">-- اختر حساب --</option>
                {accounts.map(a => {
                  const code = a.acc_code || a.code || a.id;
                  const name = a.acc_name || a.name || code;
                  return <option key={code} value={code}>{code} - {name}</option>;
                })}
              </select>
            </div>
            <div><label className="block text-sm mb-1">التاريخ</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} /></div>
            <div className="md:col-span-2"><label className="block text-sm mb-1">البيان</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.notes} onChange={e => setFormData({...formData, notes: e.target.value})} /></div>
          </div>
          <div className="flex justify-end"><button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-lg font-bold min-h-[44px]">حفظ المصروف</button></div>
        </form>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-slate-50 border-b"><tr><th className="p-3">البند</th><th className="p-3">البيان</th><th className="p-3">المبلغ</th><th className="p-3">الدفع</th><th className="p-3">التاريخ</th></tr></thead>
          <tbody>
            {expenses.map(e => (
              <tr key={e.id} className="border-b hover:bg-slate-50">
                <td className="p-3 font-medium">{e.exp_category}</td><td className="p-3">{e.notes}</td><td className="p-3 font-bold text-red-600">{e.amount} {e.currency}</td>
                <td className="p-3">{e.pay_method}</td><td className="p-3">{e.date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
