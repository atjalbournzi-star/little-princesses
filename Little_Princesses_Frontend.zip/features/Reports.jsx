function Reports({ orders, expenses, showToast }) {
  const [dateRange, setDateRange] = React.useState({ start: '', end: TODAY_STR });
  const [currency, setCurrency] = React.useState(CURRENCIES?.[0] || 'SAR');

  const filteredOrders = orders.filter(o => o.currency === currency && (!dateRange.start || o.order_date >= dateRange.start) && (!dateRange.end || o.order_date <= dateRange.end));
  const filteredExpenses = expenses.filter(e => e.currency === currency && (!dateRange.start || e.date >= dateRange.start) && (!dateRange.end || e.date <= dateRange.end));

  const totalRev = filteredOrders.reduce((sum, o) => sum + (parseFloat(o.total)||0), 0);
  const totalExp = filteredExpenses.reduce((sum, e) => sum + (parseFloat(e.amount)||0), 0);
  const netProfit = totalRev - totalExp;

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.chart} التقارير المالية</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
          <div><label className="block text-sm mb-1">من تاريخ</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={dateRange.start} onChange={e => setDateRange({...dateRange, start: e.target.value})} /></div>
          <div><label className="block text-sm mb-1">إلى تاريخ</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={dateRange.end} onChange={e => setDateRange({...dateRange, end: e.target.value})} /></div>
          <div><label className="block text-sm mb-1">العملة</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={currency} onChange={e => setCurrency(e.target.value)}>{(CURRENCIES || ["USD $", "YER ﷼", "SAR ﷼"]).map(c => <option key={typeof c === "object" ? c.value : c} value={typeof c === "object" ? c.value : c}>{typeof c === "object" ? c.label : c}</option>)}</select></div>
          <div><button className="w-full bg-slate-800 hover:bg-slate-900 text-white px-4 py-2 rounded-lg font-bold min-h-[44px]">تصفية</button></div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-slate-500 text-sm mb-1">إجمالي الإيرادات</p>
          <h3 className="text-2xl font-bold text-green-600">{totalRev.toLocaleString()} <span className="text-sm">{currency}</span></h3>
        </div>
        <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-slate-500 text-sm mb-1">إجمالي المصروفات</p>
          <h3 className="text-2xl font-bold text-red-600">{totalExp.toLocaleString()} <span className="text-sm">{currency}</span></h3>
        </div>
        <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-slate-500 text-sm mb-1">صافي الربح</p>
          <h3 className={`text-2xl font-bold ${netProfit >= 0 ? 'text-blue-600' : 'text-red-600'}`}>{netProfit.toLocaleString()} <span className="text-sm">{currency}</span></h3>
        </div>
        <div className="bg-white p-5 rounded-xl shadow-sm border border-slate-200">
          <p className="text-slate-500 text-sm mb-1">عدد الطلبات</p>
          <h3 className="text-2xl font-bold text-slate-800">{filteredOrders.length}</h3>
        </div>
      </div>
    </div>
  );
}
