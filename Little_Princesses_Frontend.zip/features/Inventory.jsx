function Inventory({ inventory, setInventory, showToast }) {
  const [formData, setFormData] = React.useState({
    item_name: '', category: FABRIC_CATEGORIES?.[0] || 'أقمشة', qty: '', cost: '', currency: CURRENCIES?.[0] || 'SAR', supply_date: TODAY_STR
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.item_name) return showToast('اسم الصنف مطلوب', 'error');
    
    const newItem = { id: Date.now(), ...formData };
    
    try {
      const res = await callGAS('addInventory', newItem);
      if (res.status === 'success') {
        setInventory([newItem, ...inventory]);
        showToast('تمت إضافة الصنف بنجاح');
      } else showToast('حدث خطأ', 'error');
    } catch (err) {
      showToast('فشل الاتصال', 'error');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm p-6 border border-slate-200">
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">{Icons.box} إضافة للمخزون</h2>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div><label className="block text-sm mb-1">اسم الصنف *</label><input type="text" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.item_name} onChange={e => setFormData({...formData, item_name: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">التصنيف</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})}>{(typeof FABRIC_CATEGORIES !== 'undefined' ? FABRIC_CATEGORIES : ['أقمشة']).map(c => <option key={c} value={c}>{c}</option>)}</select></div>
            <div><label className="block text-sm mb-1">الكمية المتوفرة</label><input type="number" step="0.1" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.qty} onChange={e => setFormData({...formData, qty: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">التكلفة (للمتر/الحبة)</label><input type="number" step="0.01" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.cost} onChange={e => setFormData({...formData, cost: e.target.value})} /></div>
            <div><label className="block text-sm mb-1">العملة</label><select className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.currency} onChange={e => setFormData({...formData, currency: e.target.value})}>{(CURRENCIES || [currency.display, "YER ﷼", "SAR ﷼"]).map(c => <option key={typeof c === "object" ? c.value : c} value={typeof c === "object" ? c.value : c}>{typeof c === "object" ? c.label : c}</option>)}</select></div>
            <div><label className="block text-sm mb-1">تاريخ التوريد</label><input type="date" className="w-full border rounded-lg p-2 min-h-[44px]" value={formData.supply_date} onChange={e => setFormData({...formData, supply_date: e.target.value})} /></div>
          </div>
          
          <div className="flex justify-end"><button type="submit" className="bg-pink-600 hover:bg-pink-700 text-white px-6 py-2 rounded-lg font-bold min-h-[44px]">حفظ الصنف</button></div>
        </form>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
        <table className="w-full text-right">
          <thead className="bg-slate-50 border-b"><tr><th className="p-3">الصنف</th><th className="p-3">التصنيف</th><th className="p-3">الكمية</th><th className="p-3">التكلفة</th><th className="p-3">تاريخ التوريد</th></tr></thead>
          <tbody>
            {inventory.map(i => (
              <tr key={i.id} className="border-b hover:bg-slate-50">
                <td className="p-3 font-medium">{i.item_name}</td><td className="p-3">{i.category}</td><td className="p-3 font-bold">{i.qty}</td>
                <td className="p-3">{i.cost} {i.currency}</td><td className="p-3">{i.supply_date}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
