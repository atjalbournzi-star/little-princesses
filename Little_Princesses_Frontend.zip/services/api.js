// GAS is called via our local Python server proxy (/api/gas) to bypass CORS.
// The Python server forwards the request to Google Apps Script server-side.
const GAS_PROXY_URL = window.location.origin + '/api/gas';

async function callGAS(action, payload = {}) {
  const body = JSON.stringify({ action, data: payload, ...payload });
  console.log("[GAS PROXY] Calling action:", action);

  const res = await fetch(GAS_PROXY_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: body
  });

  if (!res.ok) {
    const errText = await res.text().catch(() => "No response body");
    console.error("[GAS PROXY] HTTP Error:", res.status, errText);
    throw new Error(`Proxy HTTP ${res.status}: ${res.statusText}`);
  }

  const json = await res.json();
  console.log("[GAS PROXY] Response:", json);

  if (json && json.success === false) {
    throw new Error(json.error || json.message || "GAS returned success:false");
  }

  return json;
}


async function loadAllData() {
  try {
    const [cRes, iRes, aRes, pRes, oRes, puRes, fRes, vRes, eRes, jRes, fBRes] = await Promise.allSettled([
      callGAS("getCustomers"),
      callGAS("getInventory"),
      callGAS("getAccounts"),
      callGAS("getProducts"),
      callGAS("getOrders"),
      callGAS("getPurchases"),
      callGAS("getFactory"),
      callGAS("getVouchers"),
      callGAS("getExpenses"),
      callGAS("getJournalEntries"),
      callGAS("getFeedback")
    ]);

    return {
      customers: (cRes.status === "fulfilled" && cRes.value?.data && Array.isArray(cRes.value.data)) ? cRes.value.data : [],
      inventory: (iRes.status === "fulfilled" && iRes.value?.data && Array.isArray(iRes.value.data)) ? iRes.value.data : [],
      accounts: (aRes.status === "fulfilled" && aRes.value?.data && Array.isArray(aRes.value.data) && aRes.value.data.length > 0) ? aRes.value.data : (typeof INITIAL_ACCOUNTS !== 'undefined' ? INITIAL_ACCOUNTS : []),
      products: (pRes.status === "fulfilled" && pRes.value?.data && Array.isArray(pRes.value.data)) ? pRes.value.data : [],
      orders: (oRes.status === "fulfilled" && oRes.value?.data && Array.isArray(oRes.value.data)) ? oRes.value.data : [],
      purchases: (puRes.status === "fulfilled" && puRes.value?.data && Array.isArray(puRes.value.data)) ? puRes.value.data : [],
      factory: (fRes.status === "fulfilled" && fRes.value?.data && Array.isArray(fRes.value.data)) ? fRes.value.data : [],
      vouchers: (vRes.status === "fulfilled" && vRes.value?.data && Array.isArray(vRes.value.data)) ? vRes.value.data : [],
      expenses: (eRes.status === "fulfilled" && eRes.value?.data && Array.isArray(eRes.value.data)) ? eRes.value.data : [],
      journal: (jRes.status === "fulfilled" && jRes.value?.data && Array.isArray(jRes.value.data)) ? jRes.value.data : [],
      feedback: (fBRes.status === "fulfilled" && fBRes.value?.data && Array.isArray(fBRes.value.data)) ? fBRes.value.data : []
    };
  } catch (err) {
    console.warn("loadAllData failed:", err);
    return {};
  }
}

window.callGAS = callGAS;
window.loadAllData = loadAllData;
window.getFeedback = async function() {
  try {
    const res = await callGAS('getFeedback');
    return res && res.data ? res.data : [];
  } catch (e) {
    console.error('getFeedback error:', e);
    return [];
  }
};
window.addFeedback = async function(payload) {
  return await callGAS('addFeedback', payload);
};
