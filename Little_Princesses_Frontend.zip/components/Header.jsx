function Header({ activeTab, setActiveTab, allTabs, menuDrawer, setMenuDrawer }) {
  const [openDropdown, setOpenDropdown] = useState(null);

  const toggleDropdown = (name) => setOpenDropdown(prev => prev === name ? null : name);
  const closeDropdowns = () => setOpenDropdown(null);

  const prodTabs = [
    { id: 'inventory', label: 'المخزون الخام', icon: Icons.Scissors },
    { id: 'factory', label: 'متابعة الورشة والإنتاج', icon: Icons.Factory }
  ];

  const finTabs = [
    { id: 'purchases', label: 'المشتريات والتوريد', icon: Icons.Purchases },
    { id: 'vouchers', label: 'السندات المالية', icon: Icons.Vouchers },
    { id: 'expenses', label: 'المصاريف التشغيلية', icon: Icons.Expenses },
    { id: 'accounts', label: 'شجرة الحسابات', icon: Icons.Accounts },
    { id: 'journal', label: 'القيود اليومية', icon: Icons.Journal },
    { id: 'reports', label: 'التقارير المالية', icon: Icons.Reports }
  ];

  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-slate-950 via-purple-950 to-indigo-950 shadow-xl border-b border-purple-900/50 backdrop-blur-md" dir="rtl">
      <div className="flex items-center justify-between px-4 py-3 md:px-8 max-w-7xl mx-auto">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setMenuDrawer(!menuDrawer)}
            className="p-2.5 rounded-2xl bg-white/10 text-white border border-white/15 md:hidden min-h-[44px]"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              {menuDrawer ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />}
            </svg>
          </button>
          
          <div className="flex flex-col">
            <h1 className="text-base md:text-xl font-black text-amber-300 drop-shadow-sm flex items-center gap-2">
              <span>👑</span> مؤسسة الأميرات الصغيرات | ERP
            </h1>
            <span className="text-[10px] md:text-xs font-bold text-purple-200/90 tracking-wide">
              متخصصون في فساتين وأزياء الأطفال الفاخرة
            </span>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 bg-emerald-950/80 border border-emerald-500/40 px-3.5 py-1.5 rounded-full text-xs font-bold text-emerald-300 shadow-inner">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span>متصل سحابياً 🟢</span>
          </div>
        </div>
      </div>

      {menuDrawer && (
        <div className="md:hidden border-t border-purple-800/60 bg-indigo-950/95 backdrop-blur-xl p-4 animate-fadeIn">
          <div className="grid grid-cols-2 gap-2 max-h-80 overflow-y-auto">
            {allTabs.map(tab => (
              <button
                key={tab.id}
                onClick={() => { setActiveTab(tab.id); setMenuDrawer(false); }}
                className={`flex items-center gap-2.5 p-3 rounded-2xl text-xs font-bold min-h-[44px] ${activeTab === tab.id ? 'bg-rose-600 text-white font-black' : 'bg-purple-900/60 text-purple-100'}`}
              >
                {typeof tab.icon === 'function' ? tab.icon() : tab.icon}
                <span className="truncate">{tab.label}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Streamlined Desktop Dropdown Navigation */}
      <div className="hidden md:block border-t border-purple-800/40 bg-purple-950/90 py-2.5 px-6">
        <div className="flex items-center gap-2 max-w-7xl mx-auto w-full relative">
          
          <button onClick={() => { setActiveTab('dashboard'); closeDropdowns(); }} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${activeTab === 'dashboard' ? 'bg-rose-600 text-white border-rose-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
            {Icons.Dashboard()}<span>الرئيسية</span>
          </button>

          <button onClick={() => { setActiveTab('customers'); closeDropdowns(); }} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${activeTab === 'customers' ? 'bg-rose-600 text-white border-rose-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
            {Icons.Users()}<span>العملاء والمقاسات</span>
          </button>

          <button onClick={() => { setActiveTab('products'); closeDropdowns(); }} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${activeTab === 'products' ? 'bg-rose-600 text-white border-rose-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
            {Icons.Calculator()}<span>المنتجات والتسعير</span>
          </button>

          <button onClick={() => { setActiveTab('orders'); closeDropdowns(); }} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${activeTab === 'orders' ? 'bg-rose-600 text-white border-rose-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
            {Icons.ShoppingBag()}<span>الطلبات والفواتير</span>
          </button>

          {/* Production Dropdown */}
          <div className="relative">
            <button onClick={() => toggleDropdown('production')} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${['inventory', 'factory'].includes(activeTab) ? 'bg-purple-800 text-white border-purple-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
              {Icons.Factory()}<span>المخزون والإنتاج</span><span className="text-[10px]">▾</span>
            </button>

            {openDropdown === 'production' && (
              <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-purple-700/60 rounded-2xl shadow-2xl p-2 z-50 animate-fadeIn space-y-1">
                {prodTabs.map(t => (
                  <button key={t.id} onClick={() => { setActiveTab(t.id); closeDropdowns(); }} className={`w-full text-right px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${activeTab === t.id ? 'bg-rose-600 text-white font-black' : 'text-purple-100 hover:bg-purple-800'}`}>
                    {typeof t.icon === 'function' ? t.icon() : t.icon}<span>{t.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Financials Dropdown */}
          <div className="relative">
            <button onClick={() => toggleDropdown('financials')} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${['purchases', 'vouchers', 'expenses', 'accounts', 'journal', 'reports'].includes(activeTab) ? 'bg-purple-800 text-white border-purple-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
              {Icons.Accounts()}<span>المالية والحسابات</span><span className="text-[10px]">▾</span>
            </button>

            {openDropdown === 'financials' && (
              <div className="absolute right-0 mt-2 w-52 bg-slate-900 border border-purple-700/60 rounded-2xl shadow-2xl p-2 z-50 animate-fadeIn space-y-1">
                {finTabs.map(t => (
                  <button key={t.id} onClick={() => { setActiveTab(t.id); closeDropdowns(); }} className={`w-full text-right px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition ${activeTab === t.id ? 'bg-rose-600 text-white font-black' : 'text-purple-100 hover:bg-purple-800'}`}>
                    {typeof t.icon === 'function' ? t.icon() : t.icon}<span>{t.label}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <button onClick={() => { setActiveTab('feedback'); closeDropdowns(); }} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${activeTab === 'feedback' ? 'bg-rose-600 text-white border-rose-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
            {Icons.Star()}<span>الجودة</span>
          </button>

          <button onClick={() => { setActiveTab('settings'); closeDropdowns(); }} className={`flex items-center gap-2 px-4 py-2 rounded-2xl text-xs font-bold transition-all min-h-[42px] border ${activeTab === 'settings' ? 'bg-rose-600 text-white border-rose-500 shadow font-black' : 'bg-white/5 text-purple-100 border-white/10 hover:bg-white/15'}`}>
            {Icons.Settings()}<span>الإعدادات</span>
          </button>

        </div>
      </div>
    </header>
  );
}
